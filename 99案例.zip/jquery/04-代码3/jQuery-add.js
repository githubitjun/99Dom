//做加法的插件
(function ($) {
  //直接给$添加方法
  $.add = function (num1,num2) {
    return num1+num2;
  }
}(jQuery));
