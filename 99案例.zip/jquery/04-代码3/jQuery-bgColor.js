//这就是设置背景色的插件.
(function ($) {
  //给$的原型添加方法.
  $.fn.bgColor = function (bgC) {
    this.css('backgroundColor',bgC);

    return this;
  }
}(jQuery));
