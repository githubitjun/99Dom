//这是tab栏切换的插件.
(function ($) {
  /**
   * 给$的原型fn添加tabs方法.
   * @param options 对象               参数的集合
   * @param options.tabHeads          要点击的页签们选择器
   * @param options.tabHeadsClass     被点击的页签要添加的类.
   * @param options.tabBodys          要显示的页面们选择器
   * @param options.tabBodysClass     需要显示的那个页面添加的类
   */
  $.fn.tabs = function (options) {
    var $bigDiv =  this;
    //根据参数options.tabHeads 获取要点击的页签们,给他们设置点击事件.
    $bigDiv.find(options.tabHeads).on('click', function () {
      //点击的页签添加options.tabHeadsClass类,其他的页面移除options.tabHeadsClass类.
      $(this).addClass(options.tabHeadsClass).siblings().removeClass(options.tabHeadsClass);

      //获取当前点击的这个页签的索引
      var idx = $(this).index();

      //找到索引对应的页面添加options.tabBodysClass,其他的页面移除options.tabBodysClass类.
      $bigDiv.find(options.tabBodys).eq(idx).addClass(options.tabBodysClass).siblings().removeClass(options.tabBodysClass);
    })

    return this;
  }
}(jQuery));
