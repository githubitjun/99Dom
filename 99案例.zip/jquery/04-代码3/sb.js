(function (w) {
  w.$ = {
    name:'浩哥',
    age:18
  };
}(window));
