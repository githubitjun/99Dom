// 引入核心模块 url
const url = require('url')

// 路径
let str = '/del?id=1'
// 将 url 转为路径
let obj = url.parse(str, true)
console.log(obj)