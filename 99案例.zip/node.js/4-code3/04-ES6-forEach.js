// forEach:遍历数组
var arr = [1, 2, 3, 4, 5, 6, 7]

// for(var i = 0; i < arr.length; i ++) {
//     console.log(arr[i])
// }
arr.forEach((value, index) => {
    console.log(value, index)
})