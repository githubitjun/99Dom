// 路由判断： 用来设置路由
const express = require('express')
const process = require('./process.js')

const router = express.Router()

// 设置路由
router.get('/', (req, res) => {
    process.getIndex(req, res)
})
// 处理得到新增页面
router.get('/add', (req, res) => {
    process.getAdd(req, res)
})
// 处理提交数据的逻辑
router.post('/add', (req, res) => {
    process.postAdd(req, res)
})
// 处理删除路由 del?id=1
router.get('/del', (req, res) => {
    process.getDel(req, res)
})
// 处理得到修改页面的路由
router.get('/edit', (req, res) => {
    process.getEdit(req, res)
})

module.exports = router