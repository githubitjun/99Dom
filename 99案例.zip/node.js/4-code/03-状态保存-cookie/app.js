const express = require('express')
const expressTmp = require('express-art-template')
const formidable = require('formidable')
const cookieparser = require('cookie-parser')
const app = express()

app.set('view engine', 'html')
app.engine('html', expressTmp)
app.use(cookieparser())

app.get('/', (req, res) => {
    // 先判断是否已经登录了
    // 得到 cookie
    let cookie = req.cookies
    // console.log(cookie)
    console.log(req.cookies)
    if (cookie.uname) {
        // 判断是否存在  cookie
        res.render('index', {
            uname: cookie.uname
        })
    } else {
        res.send('<script>alert("对不起，您还没有登录");window.location="/login"</script>')
    }
})

// 得到登录页面
app.get('/login', (req, res) => {
    res.render('login', {})
})

// 处理 login 提交的参数
app.post('/login', (req, res) => {
    let form = new formidable.IncomingForm()
    form.parse(req, (err, fields) => {
        // 判断参数的合法性： 小追命 8888
        if (fields.uname === '小追命' && fields.pwd === '8888') {
            // 创建一个 cookie 保存信息
            res.cookie('uname', fields.uname)
            res.send('<script>alert("用户信息保存成功");window.location="/"</script>')
        } else {
            // 返回登录页面
            res.send('<script>alert("用户名或者密码不正确");window.location="/login"</script>')
        }
    })
})

app.listen(3030)