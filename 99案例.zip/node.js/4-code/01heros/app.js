// 项目的入口文件：开启服务器
// 步骤： 
//      1) 下载 express
//      2) 引入 express
//      3) 搭建服务器
//      4) 引入并使用 路由

const express = require('express')
const expressTmp = require('express-art-template')
const cookieSession = require('cookie-session')

const router = require('./router.js')

const app = express()

// 配置 art-template
app.set('view engine', 'html')
app.engine('html', expressTmp)

// 配置 静态资源
app.use('/node_modules', express.static('node_modules'))
app.use('/views', express.static('views'))

// 配置 cookie-session'
app.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2']
}))

// 添加路由
app.use(router)

app.listen(3000, () => {
    console.log('running')
})