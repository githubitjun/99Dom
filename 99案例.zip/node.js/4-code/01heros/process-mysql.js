const formidable = require('formidable')

// 引入 db.js
const db = require('./db.js')

// 处理得到登录页面
exports.getLogin = (req, res) => {
    // 响应登录页面
    res.render('login', {})
}

// 处理 login 提交的数据
exports.postLogin = (req, res) => {
    // 1.0 接收参数
    let form = new formidable.IncomingForm()
    form.parse(req, (err, fields) => {
        if (fields.uname == 'admin' && fields.pwd == '8888') {
            // 将登录信息保存起来
            // 2.0 判断参数的合法性
            req.session.obj = {
                uname: fields.uname,
                pwd: fields.pwd
            }
            // 3.0 响应结果
            res.send(`<script>alert('登录成功');window.location='/'</script>`)
        } else {
            res.send(`<script>alert('登录不成功');window.location='/login'</script>`)
        }
    })
}

// 将数据转移到 mysql 后的逻辑处理
exports.getIndex = (req, res) => {
    // 1.0 获取数据
    // 创建 sql
    let sql = `SELECT * FROM hero`
    db.query(sql, (result) => {
        // 2.0 渲染页面
        res.render('index', {
            heros: result
        })
    })
}

// 得到新增页面
exports.getAdd = (req, res) => {
    res.render('add', {})
}

// 处理新增提交数据
exports.postAdd = (req, res) => {
    // 1.0 接收数据
    let form = new formidable.IncomingForm()
    form.parse(req, (err, fields) => {
        if (err) return
        fields.img = 'views/img/1.jpg'
        // 2.0 将数据保存到 mysql 中
        let sql = `INSERT INTO hero (name, gender, img) VALUES ('${fields.name}','${fields.gender}','${fields.img}')`
        db.query(sql, (results) => {
            if (results.affectedRows >= 1) {
                // 3.0 返回处理结果
                res.send('<script>alert("新增成功");window.location="/"</script>')
            }
        })
    })
}

// 处理删除逻辑
exports.getDel = (req, res) => {
    // 1.0 接收 id
    let id = req.query.id
    // 2.0 根据 id 去数据库中删除数据
    let sql = `DELETE FROM hero WHERE id = ${id}`
    db.query(sql, result => {
        if (result.affectedRows >= 1) {
            // 3.0 响应结果
            res.send('<script>alert("删除成功");window.location="/"</script>')
        }
    })
}

// 处理 得到修改页面
exports.getEdit = (req, res) => {
    // 1.0 接收 id 参数
    let id = req.query.id
    // 2.0 根据 id 到 mysql 中获取数据
    let sql = `SELECT * FROM hero WHERE id = ${id}`
    db.query(sql, result => {
        // 3.0 响应修改页面
        res.render('edit', result[0])
    })
}

// 处理修改提交的数据
exports.postEdit = (req, res) => {
    // 1.0 接收post 的参数： id name gender
    let form = new formidable.IncomingForm()
    form.parse(req, (err, fields) => {
        if (err) return
        // 2.0 根据数据进行修改 mysql
        let sql = `UPDATE hero SET name = '${fields.name}', gender='${fields.gender}' WHERE id = ${fields.id}`
        db.query(sql, result => {
            if (result.affectedRows >= 1) {
                res.send('<script>alert("修改成功");window.location="/"</script>')
            }
        })
    })
}

// 处理错误
module.exports.processErr = (err, req, res) => {
    // 1.0 将异常信息保存到 日志文件 中
    // 2.0 响应一个 404 页面回浏览器
    res.render('404', {})
}