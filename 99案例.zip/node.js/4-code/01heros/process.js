const fs = require('fs')
const path = require('path')
const querystring = require('querystring')
const uurl = require('url')

const formidable = require('formidable')



// 处理逻辑
// 处理 get 请求 根目录
module.exports.getIndex = (req, res) => {
    // 读取 db.json 中的数据，并且渲染到 index.html 中
    // 1.0 读取
    fs.readFile('./db.json', (err, data) => {
        if (err) return
        let heros = JSON.parse(data.toString())
        // 2.0 将数据进行渲染
        res.render('index', heros)
    })
}

// 处理 get 请求的 add
module.exports.getAdd = (req, res) => {
    // 1.0 读取 add
    // 2.0 响应
    res.render('add', {})
}

// -------------------------使用第三方包 formidabel 来接收参数（推荐使用）----------------------------
module.exports.postAdd = (req, res) => {
    // 1.0 接收参数：使用 formidable
    //  创建对象 
    let form = new formidable.IncomingForm()
    //  调用方法
    form.parse(req, (err, fields, files) => {
        if (err) return
        // 2.0 根据参数生成对象
        fields.img = 'views/img/0.jpg'
        // 3.0 得到 db.json 中的数据对象
        fs.readFile(path.join(__dirname, './db.json'), (err1, data) => {
            let herosObj = JSON.parse(data.toString())
            fields.id = herosObj.heros[herosObj.heros.length - 1].id + 1
            // 4.0 将新增对象添加到 db.json 的数据对象中
            herosObj.heros.push(fields)
            // 5.0 重新写入
            let herosStr = JSON.stringify(herosObj, null, '  ')
            fs.writeFile(path.join(__dirname, './db.json'), herosStr, err3 => {
                if (err3) return
                // 6.0 响应
                res.send('<script>alert("添加成功");window.location="/"</script>')
            })
        })
    })
}
// 处理删除的逻辑
module.exports.getDel = (req, res) => {
    // 1.0 接收要删除数据的 id
    // let url = req.url
    // let query = uurl.parse(url, true).query
    let id = req.query.id
    // 2.0 读取 db.json 中的数据对象
    fs.readFile(path.join(__dirname, './db.json'), (err, data) => {
        if (err) return
        let herosObj = JSON.parse(data.toString())
        // 3.0 从数据对象中找到 id 对应的数据
        herosObj.heros.forEach((value, index) => {
            if (value.id == id) {
                // 将当前数据从数组中删除
                // 4.0 删除这条数据
                herosObj.heros.splice(index, 1)
            }
        })
        // 5.0 重新将结果写入到 db.json 中
        let herosStr = JSON.stringify(herosObj, null, '  ')
        fs.writeFile(path.join(__dirname, './db.json'), herosStr, err1 => {
            if (err1) return
            // 6.0 响应操作的结果
            res.send('<script>alert("删除成功");window.location="/"</script>')
        })
    })
}

// 处理 get edit 逻辑
module.exports.getEdit = (req, res) => {
    // 1.0 接收参数 id
    let id = req.query.id
    // 2.0 得到 db.json 中的数据对象
    fs.readFile(path.join(__dirname, './db.json'), (err, data) => {
        if (err) return
        let herosObj = JSON.parse(data.toString())
        let obj;
        // 3.0 根据 id 得到 db.json 中数据里对应的数据
        herosObj.heros.forEach(value => {
            if (value.id == id) {
                obj = value
            }
        })
        // 4.0 将静态页面与 数据进行渲染，将结果返回到浏览器
        res.render('edit', obj)
    })
}

// 处理修改的提交数据
module.exports.postEdit = (req, res) => {
    // 1.0 接收参数
    let form = new formidable.IncomingForm()
    // fields
    // { id: 1, name: '', gender }
    form.parse(req, (err, fields, files) => {
        if (err) return
        // 2.0 根据 id 找到 db.json 中对应的数据
        fs.readFile(path.join(__dirname, './db.json'), (err1, data)=> {
            if (err1) return
            let herosObj = JSON.parse(data.toString())
            herosObj.heros.forEach(value => {
                if (value.id == fields.id) {
                    // 3.0 将数据进行修改
                    value.name = fields.name
                    value.gender = fields.gender
                }
            })
            // 4.0 更新 db.json 中的数据
            let herosStr = JSON.stringify(herosObj, null, '  ')
            fs.writeFile(path.join(__dirname, './db.json'), herosStr, err => {
                if (err) return
                // console.log('修改完成')
                // 5.0 将结果响应回浏览器
                res.send('<script>alert("修改成功");window.location="/"</script>')
            })
        })
    })
}