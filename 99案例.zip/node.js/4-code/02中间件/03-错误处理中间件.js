const express = require('express')
let app = express()

app.use((err, req, res, next) => {
    console.log('出错啦')
    res.send('出错啦')
})

app.get('/', (req, res) => {
    console.log('根目录')
    res.send('根目录')
})
app.get('/abc', (req, res) => {
    throw new Error()
    console.log('/abc')
    res.send('abc')
})

app.listen(3000)