const express = require('express')

let app = express()

// 在处理所有的请求之前，我们提前输出一句话：这是输出在最前面的内容
// next: 决定后续代码是否继续执行
app.use((req, res, next) => {
    console.log('这是输出在最前面的内容')
    // 加入登录判断
    // 任意我们需要的代码
    next()
})

app.get('/abc', (req, res, next) => {
    console.log('这是get')
    next()
})

app.get('/abc', (req, res, next) => {
    console.log('第二个 abc')
    next()
})

app.get('/abc', (req, res) => {
    console.log('/abc')
})

app.get('/', (req, res) => {
    console.log('/root')
})
app.listen(3000)