const express = require('express')
const router = express.Router()

// 路由级中间件
router.use((req, res, next) => {
    console.log('use')
    next()
})
router.use('/abc', (req, res, next) => {
    console.log('use abc')
    next()
})

router.get('/abc', (req, res, next) => {
    console.log('abc 第一次')
    next()
})

router.get('/abc', (req, res) => {
    console.log('abc')
})

module.exports = router