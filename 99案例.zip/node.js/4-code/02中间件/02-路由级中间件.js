const express = require('express')
const router = require('./02router.js')
let app = express()

app.use(router)

app.listen(3000)