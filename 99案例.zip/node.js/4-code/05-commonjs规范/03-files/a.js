console.log('a.js')
exports.obj = {
    age: 18
}