console.log('03-files/index.js')
exports.obj = {
    name: '小追命'
}