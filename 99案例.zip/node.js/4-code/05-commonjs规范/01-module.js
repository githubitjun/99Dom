console.log('我是 01-module')

var name = '小追命'
var sayHi = () => {
    console.log('大家好，我叫小追命')
}
module.exports = {
    name,
    sayHi
}