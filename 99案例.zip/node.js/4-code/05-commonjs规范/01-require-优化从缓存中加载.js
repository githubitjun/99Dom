// 引入模块
const module01 = require('./01-module.js')
const module02 = require('./01-module.js')
const module03 = require('./01-module.js')

console.log('我是 01 require')