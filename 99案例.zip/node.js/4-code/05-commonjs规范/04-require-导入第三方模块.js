const moment = require('moment')

let time = moment(Date.now()).format('YYYY-MM-DD hh:mm:ss a')
console.log(time)