const express = require('express')
const expressTmp = require('express-art-template')
const formidable = require('formidable')
// const session = require('express-session')
const cookieSession = require('cookie-session')
const app = express()

// 注册模板引擎
app.set('view engine', 'html')
app.engine('html', expressTmp)
// 注册  session
// app.use(session({
//     secret: 'keyboard cat',
//     resave: false,
//     saveUninitialized: true
// }))
app.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2']
}))

app.get('/', (req, res) => {
    // 得到 session.uname
    let session = req.session.obj
    if (session && session.uname) {
        res.render('index', {
            uname: session.uname
        })
    } else {
        res.send(`<script>alert('还没有登录');window.location='/login'</script>`)
    }
})

app.get('/login', (req, res) => {
    res.render('login', {})
})

app.post('/login', (req, res) => {
    let form = new formidable.IncomingForm()
    form.parse(req, (err, fields) => {
        if (err) return
        if (fields.uname == 'admin' && fields.pwd == '8888') {
            // 将用户信息用 session 保存起来
            req.session.obj = {
                uname: fields.uname,
                pwd: fields.pwd
            }
            // 跳转到首页
            res.send(`<script>alert('登录成功');window.location='/'</script>`)
        } else {
            res.send(`<script>alert('登录失败');window.location='/login'</script>`)
        }
    })
})

app.listen(3030)