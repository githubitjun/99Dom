"use strict";

var a = 123;
var b = 'abc';

var sayHi = function sayHi() {
  console.log('sayHi');
};
