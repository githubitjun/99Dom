let a = 123
const b = 'abc'
let sayHi = () => {
    console.log('sayHi')
}