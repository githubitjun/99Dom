// 在 nodejs 中开启服务器
// 在 node 中如果需要开启服务器，需要引入一个模块： http

// 1.0 引入 http 模块
let http = require('http') // http 就是 node 可以用来开启服务器的模块
let fs = require('fs')

// 2.0 创建一个服务器对象
var server = http.createServer()

// 3.0 设置请求处理函数
server.on('request', function(request, response) {
    console.log('有请求过来了')
    // 将内容读取出来
    fs.readFile('./00.txt', (err, data) => {
        // 将来如果有请求过来，我们不管三七二十一直接将 00.txt 中的内容返回
        response.end(data.toString())
    })
})

// 4.0 开启服务器
// listen 开启服务器
//  port: 端口号
//  192.168.43.39: ip地址
server.listen(3000, '192.168.1.53', function() {
    console.log('服务器开启成功')
})