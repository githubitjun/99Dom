// 演示 marked 的使用
// 引入 require 
let marked = require('marked')

// md 的字符串
var mdStr = `# 标题
+ 列表选项1
+ 列表选项2
+ 列表选项3`
// 转换为 html
let htmlStr = marked(mdStr)
console.log(htmlStr)