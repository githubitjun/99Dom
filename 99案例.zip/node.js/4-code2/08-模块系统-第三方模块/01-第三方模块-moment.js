// 得到当前时间，并且输出
// Date.now： 获取当前时间

// 引入第三方模块
let moment = require('moment')

var date = Date.now()
// 使用 moment 中的 API
var time = moment(date).format('YYYY-MM-DD hh:mm:ss')
console.log(time)