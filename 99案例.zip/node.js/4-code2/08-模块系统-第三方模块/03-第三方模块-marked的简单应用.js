// 需求：将 day02.md 转为一个 html 页面
// 1）得到 day02.md 中的内容
//  1.1 引入核心模块 fs
//  1.2 调用方法 readFile 方法
// 2）将内容通过 marked 进行转换
//  2.1 下载
//  2.2 引徼
//  2.3 转换
// 3）写入为一个 html 页面
//  3.1 调用方法 writeFile

let fs = require('fs')
let marked = require('marked')
fs.readFile('./day02.md', (err, data) => {
    if (err) return
    let result = marked(data.toString())
    // 写入
    fs.writeFile('./index.html', result, err => {
        if (err) return
        console.log('day02.md 已经转为 index.html')
    })
})