# Node.js

## 命令行(CMD)

- 学习 Node.js 离不开命令行环境

- 作为一名前端开发工程师，**日常工作是离不开命令行的**，因为有**一些工作只有通过命令才能完成**。其中包括：

  1. 使用 Node.js 开发的工具
  2. 从服务器获取或提交源代码
  3. 开启测试 Web 服务器
  4. 代码压缩、合并

  例如：**从服务器获取代码**这件工作，**可能会是我们就业进入新公司要做的第一件事情**！

  > 提示：终端命令不需要死记硬背！命令用的多，自然能记住；命令用的少，临时去百度。

### 命令行介绍

在图形化的 `Windows` 操作系统问世之前，人们使用 `DOS` 操作系统来操作计算机。其界面类似于 `Windows` 系统自带的**命令行工具**，如下图所示：

<img src="assets/01_%E5%91%BD%E4%BB%A4%E8%A1%8C%E7%AA%97%E5%8F%A3.png" width="700">

> 通过命令行命令，可以执行诸如：**磁盘操作**、**文件存取**、**目录操作**、**进程管理**等操作。

### 打开命令行的方式

- **方式1**：按快捷键 `win+r`，然后输入 `cmd`，如下图所示

  <img src="assets/03_%E8%BF%90%E8%A1%8C_%E5%91%BD%E4%BB%A4%E8%A1%8C.png" width="400"  />

- **方式2**： **shitf** + **鼠标右键**

  <img src="assets/Snipaste_2019-04-24_20-26-45.png" width="400"  />

### 命令行中的路径

- 打开命令行窗口后，在**窗口的左上角位置**，会显示**当前所在的位置**，如下图所示：<img src="assets/04_%E5%91%BD%E4%BB%A4%E8%A1%8C%E7%9A%84%E8%B7%AF%E5%BE%84.png" width="500" />

  > 使用 `dir` 命令看到的内容，会和使用**资源浏览器**查看 `C:\Users\黑马程序员`的内容一致。其中：
  >
  > - `C:` 表示**盘符**；
  > - `\`表示**目录的层次关系**；
  > - `>` 在后面输入命令。
  >
  > 截图中的目录表示：**`C 盘` 下的 `Users` 目录下的 `黑马程序员` 目录**。
  >
  > **注意**：在命令行中，单独使用的 `\`，表示**当前盘符的根目录**。


### cd 命令

| 命令        | 含义          |
| --------- | ----------- |
| `cd \`    | 切换到**根目录**  |
| `cd .`    | 保持在当前目录不变   |
| `cd ..`   | 切换到**上级目录** |
| `cd [目录]` | 切换到指定目录     |

#### 切换盘符

**注意**：`cd` 命令**只能切换目录，不能修改盘符**，要修改盘符，必须**使用盘符命令**。如下图所示：

<img src="assets/05_%E5%91%BD%E4%BB%A4%E8%A1%8C%E5%88%87%E6%8D%A2%E7%9B%98%E7%AC%A6.png" width="560" />

**提示**：

1. 盘符的**字母不区分大小写**；
2. 盘符的冒号 `:` 后面不要使用 `\`。

### 常用命令（掌握）

|  序号  | 英文                       | 命令                  | 作用            |
| :--: | ------------------------ | ------------------- | ------------- |
|  01  | **dir**ectory            | `dir [目录名]`         | 列出目录中的所有文件    |
|  02  | **c**hange **d**irectory | `cd [目录名]`          | 切换目录          |
|  03  |                          | `盘符:`，如：`c:`、`d:` 等 | 切换盘符          |
|  04  | **m**ake **d**irectory   | `md [目录名]`          | 创建文件夹（知道）     |
|  05  | **r**emove **d**irectory | `rd [目录名]`          | 删除文件夹（知道）     |
|  06  | clear                    | `cls`               | 清屏            |
|  07  | **exit**                 | `exit`              | 退出命令行，关闭命令行窗口 |

### 小技巧（掌握）

**粘贴和复制**

- **粘贴**：**点击鼠标右键**，可以将之前在其他位置复制过的文本**粘贴到当前命令行**。
- **复制**：在命令行窗口中选中一段文本后，**点击鼠标右键**，可以复制选中的文本。
- **自动补全**：在敲出**文件/目录**的前几个字母后，按下 **tab** 键
- **历史命令**：按**上/下光标键**可以在曾经使用过的命令间来回切换
- **退出当前命令**：CTRL + C

### REPL 环境

> node 可以在 CMD 中进入 REPL 环境， REPL类似于浏览器中的 Console ，可以做一些基本的代码测试。
>
> - R：Read 读取
> - E：Eval 执行
> - P：Print 输出
> - L：Loop 循环

- 进入
  - 输入 `node` 回车即可
- 使用
- 离开
  - 按住 `Ctrl` 不要丢，`c` 两次即可退出

![image-20181107154211879](assets/image-20181107154211879.png)

## 模块系统

> JavaScript一直没有模块（module）体系， 无法将一个大程序拆分成互相依赖的小文件

### 什么是模块系统

![1543760225002](assets/1543760225002.png)

- 现实角度（手机、电脑）
  - 生产效率高
  - 可维护性好
- 程序角度
  - 就是把大一个文件中很多的代码拆分到不同的小文件中，每个小文件就称之为一个模块
  - 开发效率高
  - 可维护性好

### 模块分类

在 Node 中对模块的一个具体分类，一共就三种类别：

- 文件模块
  - 就是我们自己写的功能模块文件
- 核心模块
  - Node 平台自带的一套基本的功能模块，也有人称之为 Node 平台的 API 
- 第三方模块
  - 社区或第三方个人开发好的功能模块，可以直接拿回来用
  - 使用的时候我们需要通过 `npm` 进行下载然后才可以加载使用，例如： `moment`、`marked`

### 文件模块

#### 模块化的特点

+ Node.js 采用的模块化结构是按照 CommonJS 规范(CommonJS 就是一套约定标准，不是技术)

- 模块与文件是一一对应关系，即加载一个模块，实际上就是加载对应的一个模块文件(所谓的模块就是一个js文件)
- 每一个模块都有自己的作用域
- 模块开发的流程

![1545105308202](assets/1545105308202.png)

#### 模块的通信规则

+ 导出模块 `module.exports`

  提供一个可以进行数学运算的模块，新建文件 `math.js`

  ```javascript
  module.exports.add = (a, b) => {
    return a + b;
  }

  module.exports.sub = (a, b) => {
    return a - b;
  }
  ```

  导出模块中的成员：可以是方法也可以是属性

  ```javascript
  module.exports.a = 5;
  module.exports.b = 10;
  ```

+ 导入模块 `require` 

  导入自己写的模块，注意要使用**相对路径**

  ```javascript
  // 注意 ./ 不能省略
  const math = require('./math.js');
  console.log(math.add(5, 5));
  console.log(math.sub(5, 5));
  ```

### 核心模块

- 核心模块就是 Node 内置的模块，需要通过唯一的标识名称来进行获取。
- 每一个核心模块基本上都是暴露了一个对象，里面包含一些方法供我们使用
- 一般在加载核心模块的时候，变量的起名最好就和核心模块的标识名同名即可
  - 例如：`const fs = require('fs')`

#### `path` 模块

- 操作文件的时候经常要对文件的路径做处理，或者获取文件的后缀，使用 `path` 模块。
- `path` 是 Node 本身提供的一个核心模块，专门用来处理路径。
- `path` 仅仅用来处理路径的字符串。

##### 常用API
| 方法                         | 作用                  |
| -------------------------- | ------------------- |
| path.basename(path[, ext]) | 返回 path 的最后一部分(文件名) |
| path.dirname(path)         | 返回目录名               |
| path.extname(path)         | 返回路径中文件的扩展名(包含.)    |
| path.format(pathObject)    | 将一个对象格式化为一个路径字符串    |
| path.join([...paths])      | 拼接路径                |
| path.parse(path)           | 把路径字符串解析成对象的格式      |
| path.resolve([...paths])   | 基于当前**工作目录**拼接路径    |

  > 工作目录：当前运行 Node 程序的目录

#### `fs` 模块

- 文件系统，对文件/文件夹的操作  file system

##### 常用 API

| API                                      | 作用        | 备注      |
| ---------------------------------------- | --------- | ------- |
| fs.access(path, callback)                | 判断路径是否存在  |         |
| fs.appendFile(file, data, callback)      | 向文件中追加内容  |         |
| fs.copyFile(src, callback)               | 复制文件      |         |
| fs.mkdir(path, callback)                 | 创建目录      |         |
| fs.readDir(path, callback)               | 读取目录列表    |         |
| fs.rename(oldPath, newPath, callback)    | 重命名文件/目录  |         |
| fs.rmdir(path, callback)                 | 删除目录      | 只能删除空目录 |
| fs.stat(path, callback)                  | 获取文件/目录信息 |         |
| fs.unlink(path, callback)                | 删除文件      |         |
| fs.watch(filename[, options]\[, listener]) | 监视文件/目录   |         |
| fs.watchFile(filename[, options], listener) | 监视文件      |         |

#### 常用核心模块

| 模块名称                                     | 作用       |
| ---------------------------------------- | -------- |
| [fs](https://nodejs.org/dist/latest-v10.x/docs/api/fs.html) | 文件操作     |
| [http](https://nodejs.org/dist/latest-v10.x/docs/api/http.html) | 网络操作     |
| [path](https://nodejs.org/dist/latest-v10.x/docs/api/path.html) | 路径操作     |
| [url](https://nodejs.org/dist/latest-v10.x/docs/api/url.html) | url 地址操作 |
| [os](https://nodejs.org/dist/latest-v10.x/docs/api/os.html) | 操作系统信息   |
| [querystring](https://nodejs.org/dist/latest-v10.x/docs/api/querystring.html) | 解析查询字符串  |
| ...                                      | ...      |

**核心模块本质上也是文件模块**

- 核心模块已经被编译到了 node 的可执行程序，一般看不到
- 可以通过查看 node 的源码看到核心模块文件


### 第三方模块

- 社区或第三方个人开发好的功能模块，可以直接拿回来用。使用之前可以去 `github` 搜索使用的规则。
- 需要使用到 `npm`

#### 什么是 `npm`

- `npm` 全称 `Node Package Manager`(Node 包管理器)，它的诞生是为了解决 Node 中第三方包共享的问题。
- `npm` 是不需要单独安装。在安装 Node 的时候，会连带一起安装 `npm`。
- `npm` [官网](https://www.npmjs.com/)
  - 每星期大约有 30 亿次的下载量，包含超过 600000 个 *包*


#### 演示第三方模块

- 创建项目文件夹 `demo`

- 在命令行切换到 `demo` 文件夹

- 初始化 `package.json` 

  ```bash
  # 切换到 demo 文件夹，在命令行运行(确保当前文件夹没有中文)
  npm init -y
  ```

  > 注意：**项目文件夹不能有中文**

- 安装需要的第三方模块

#### moment

- 一个强大的第三方模块，对日期进行处理

- [moment 官网](http://momentjs.com/)

- Node.js / 浏览器环境都可以使用

- 安装

  ```bash
  # 需要联网，通过网络下载第三方包
  npm install moment
  ```

  > 第三方包，默认被下载到 node_modules 文件夹

- 使用

  ```js
  const moment = require('moment');

  console.log(moment(new Date()).format('YYYY-MM-DD HH:mm:ss'));
  ```

#### marked

- 一个 markdown 语法的编译器，能够把 markdown 语法转换成 HTML。

- [marked 官网](https://github.com/markedjs/marked)

- Node.js / 浏览器环境都可以使用

- 安装

  ```bash
  npm install marked
  ```

- 使用

  ```js
  const marked = require('marked');
  let html = marked('# Marked in the browser\n\nRendered by **marked**.');
  ```

##### 案例：Markdown 文件转换器

> 需求：用户编写 md 格式的文件，**实时**的编译成 html 文件

```js
// 监视文件的变化
fs.watchFile('1.md', (curr, prev) => {
  // 读取1.md的内容，保存到1.html中
  fs.readFile('1.md', 'utf-8', (err, data) => {
    let html = marked(data);
    fs.writeFile('1.html', html, (err) => {
      console.log('ok');
    });
  });
});
```

## 全局对象和全局变量

了解 Node 的最基本成员以及核心概念

[Node.js 中文文档](http://nodejs.cn/)

[Node.js 官网](https://nodejs.org/en/)

### 全局对象

#### global

- [全局变量](http://nodejs.cn/api/globals.html)
- 类似于客户端  JavaScript 运行环境中的 window
- node.js 中的全局对象是 `global`，全局对象中的成员直接使用不需要包含它

### 全局变量

- process
  - 进程：每一个 正在运行 的应用程序都称之为进程
  - 用于获取当前的 Node 进程信息，一般用于获取环境变量之类的信息
  - process.cwd()  获取 Node的**工作目录**(执行 Node 程序的目录)
- console
  - Node.js 中内置的 console 模块，提供操作控制台的输出功能，常见使用方式与客户端类似

### 全局函数

- setInterval/clearInterval
- setTimeout/clearTimeout

## 模块内的全局环境(伪)

http://nodejs.cn/api/globals.html

- **__filename**
  - 用于获取当前文件所在目录的完整路径
  - 在 REPL 环境无效
- **__dirname**
  - 用来获取当前文件的完整路径
  - 在 REPL 环境同样无效
- module
  - 模块对象
  - **module.exports**  模块中最终导出的对象
  - module.id 模块的识别符，通常是带有绝对路径的模块文件名
  - module.filename 模块定义的文件的绝对路径。
- exports
  - 映射到 module.exports 的别名
- require()
  - 加载**文件模块**时候可以省略后缀名，默认加载 `.js` 文件
  - `require` 的基本功能是，读入并执行一个 JavaScript 文件，然后返回该模块的 module.exports 对象。 
  - 如果没有发现指定模块，会报错。