// 输入 hello world
let str = 'hello world'
console.log(str)