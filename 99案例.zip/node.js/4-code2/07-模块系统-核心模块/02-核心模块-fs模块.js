// fs：文件IO
// 引入 fs 模块
let fs = require('fs')
// // 文件的读取
// fs.readFile('../00.txt', (err, data) => {
//     if (err) return
//     console.log(data.toString())
// })

// 文件的写入
// writeFile：文件的写入
//  file: 文件路径
//  data：写入的内容
//  callback：回调函数
//      err：异常信息
var str = 'good good study, day day up'
fs.writeFile('../00.txt', str, err => {
    if (err) return
    console.log('写入成功')
})

