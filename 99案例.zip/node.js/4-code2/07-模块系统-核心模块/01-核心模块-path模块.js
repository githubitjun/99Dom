// 操作路径：
// 核心模块 path:
// 1）引用核心模块 path
let path = require('path')

// 2）处理路径：
var pathStr = 'C:/Users/91300/Desktop/nodejs/day02/4-code/00.txt'
// // 得到文件名
// let basename = path.basename(pathStr)
// console.log(basename)
// // 得到后缀名
// let extname = path.extname(pathStr)
// console.log(extname)
// // 得到文件的目录
// let dirname = path.dirname(pathStr)
// console.log(dirname)
// // 拼接两个路径
// var str1 = '/a/b/c/d'
// var str2 = 'e/f/g'
// var str = path.join(str1, str2)
// console.log(str)
// 可以将一个路径字符串，转为一个路径对象
let pathObj = path.parse(pathStr)
console.log(pathObj)