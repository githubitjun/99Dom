// 处理计算的逻辑（比较复杂：此处有1万行代码）

// 要使用：先引入
let fz = require('./02-fengzhuangjisuan.js')

var num1 = 1000
var num2 = 500
// 计算和
console.log(fz.add(num1, num2))
// 计算差
console.log(fz.sub(num1, num2))