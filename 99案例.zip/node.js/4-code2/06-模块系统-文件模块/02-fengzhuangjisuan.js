// 定义方法: 加，减
function add(num1, num2) {
    return num1 + num2
}
function sub(num1, num2) {
    return num1 - num2
}

// 被使用：要暴露
module.exports.add = add
module.exports.sub = sub 