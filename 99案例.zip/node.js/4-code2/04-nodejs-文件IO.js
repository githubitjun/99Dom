// 使用 nodejs 的代码来读取文件
// 引入 node 中可以操作文件的模块
let fs = require('fs') // fs 就是 node 中可以用来读取文件的模块

// 读取
// readFile： 可以用来读取文件
//      path: 被读取文件的路径
//      callback: 读取后的回调函数
//          err：读取异常时的异常信息
//          data：读取成功时的成功信息
// 由于读取文件时，会将内容以 十六进制 的方式读取，所以需要将内容转为字符串
fs.readFile('./00.txt', function(err, data) {
    if (err) {
        console.log('哎呀，出错了')
        return 
    } 
    console.log(data.toString())
}) 