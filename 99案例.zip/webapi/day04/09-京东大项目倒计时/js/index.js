
//-------------页面顶部广告开始-----------------------------
//1.获取元素
var closeTopAd = document.getElementById('closeTopAd');
var banner = document.getElementById('banner');
//2.注册事件
closeTopAd.onclick = function () {
    //3.事件处理:隐藏广告栏

    //第一种：display
    // banner.style.display = 'none';
    //第二种方式：innerHTML
    banner.innerHTML = '';
    //注意点：innerHTML只能操作元素子元素，不能修改元素自身
    banner.style.height = '0px';

}
//-------------页面顶部广告结束-----------------------------

/*思路分析 
1.开启一个永久定时器。时间间隔1s。
  (1).获取页面元素的文本。 h m s
  (2).每过1s， s--
  (3). 如果s < 0, s = 59,m--
  (4) 如果 m < 0, m = 59,h--
  (5)如果hms < 10，则在前面加上0  
  (5)将计算好的时分秒hms赋值给页面元素文本
  (6)如果 s == 0 && m == 0 && h == 0,清除定时器
*/

var timeID = setInterval(function(){
  //(1).获取页面元素的文本。 h m s
  var hDiv = document.getElementById('spanHour');
  var mDiv = document.getElementById('spanMin');
  var sDiv = document.getElementById('spanSec');
  var h = hDiv.innerText;
  var m = mDiv.innerText;
  var s = sDiv.innerText;
  //(2).每过1s， s--
  s--;
  //(3). 如果s < 0, s = 59,m--
  if(s < 0){
    s = 59;
    m--;
  };
  //(4) 如果 m < 0, m = 59,h--
  if(m < 0){
    m = 59;
    h--;
  };

  //(5)如果h m s < 10，则在前面加上0 
  /*注意点： 不要直接用字符串和数字计算，应该先转成number类型 */
  s = parseInt(s);
  m = parseInt(m);
  h = parseInt(h);
  s =  s < 10?'0' + s:s;
  m =  m < 10?'0' + m:m;
  h =  h < 10?'0' + h:h;
  //(6)将计算好的时分秒hms赋值给页面元素文本
  hDiv.innerText = h;
  mDiv.innerText = m;
  sDiv.innerText = s;
  //(7)如果 s == 0 && m == 0 && h == 0,清除定时器
  if(s == 0 && m == 0 && h == 0){
    clearInterval(timeID);
  }
},1000)

//-----------------页面秒杀部分结束-------------------------------------
