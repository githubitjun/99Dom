
//-------------1.点击顶部关闭按钮隐藏banner条-----------------------------

//1.获取元素
var closeTopAd = document.getElementById('closeTopAd');
var banner = document.getElementById('banner');
//2.注册事件
closeTopAd.onclick = function () {
    //3.事件处理:隐藏广告栏

    //第一种：display
    // banner.style.display = 'none';
    //第二种方式：innerHTML
    banner.innerHTML = '';
    //注意点：innerHTML只能操作元素子元素，不能修改元素自身
    banner.style.height = '0px';
};

//-------------页面顶部广告结束-----------------------------
